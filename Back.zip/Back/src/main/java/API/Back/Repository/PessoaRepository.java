//package API.Back.Repository;

//import org.springframework.data.repository.CrudRepository;
//import API.Back.Entity.Pessoa;

//public interface PessoaRepository extends CrudRepository<Pessoa, Long> {
//}
